STYLE VEELLAA Android project

Is folder ko Android Studio mein open karein:
1. Android Studio install karein (Windows/Mac/Linux computer par).
2. File > Open karke is project folder ko select karein.
3. Android Studio ko Gradle sync aur Android SDK install karne dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) select karein.
5. APK app/build/outputs/apk/debug/app-debug.apk mein milegi.
6. APK ko phone par bhej kar install karein. Phone mein zarurat pade to 'Install unknown apps' permission dein.

Zaroori limitations:
- Yeh starter/demo app hai. Booking data sirf usi device ke browser storage mein rehta hai.
- Customers ke phones aur salon owner ke phone ke beech bookings sync nahi hoti.
- Payment, WhatsApp/SMS notification, cloud database, staff accounts aur online deployment abhi included nahi hain.
- Is project ko APK mein compile karne ke liye Android Studio aur Android SDK wala computer chahiye.
